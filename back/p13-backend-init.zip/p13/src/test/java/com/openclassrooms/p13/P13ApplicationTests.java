package com.openclassrooms.p13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
